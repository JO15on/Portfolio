export interface IWork {
    image : string;
    title : string;
    view : string;   
}
