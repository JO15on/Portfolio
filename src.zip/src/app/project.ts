export interface IProject {
    image: string;
    title: string;
    desc: string;
    url: string;
    full: string;
}

