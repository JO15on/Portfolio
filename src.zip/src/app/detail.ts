export interface IDetail {
    image : string;
    image2: string;
    image3: string;
    title : string;
    sub_title : string;
    desc : string; 
}
